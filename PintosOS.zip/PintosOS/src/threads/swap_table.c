#include "lib/kernel/bitmap.h"

//Create bit map
// struct bitmap *bitmap_create (size_t bit_cnt);
struct swap_bitmap = &bitmap_create (size_t bit_cnt); 

//swap slots should be page-aligned because there is no downside in doing so.
//How do we page-align them??




