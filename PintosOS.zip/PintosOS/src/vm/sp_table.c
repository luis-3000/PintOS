#include <hash.h>
#include "sp_table.h"
#include "threads/vaddr.h"
#include <debug.h>
#include "threads/palloc.h"
#include "threads/synch.h"

struct hash pages;
struct lock sp_lock;	/* Lock for the frame table */
struct page *next_page;

unsigned sp_hash_func (const struct hash_elem *e, void *aux UNUSED);
bool sp_less_func (const struct hash_elem *a, const struct hash_elem *b, void *aux);

/* Initialize the frame table. */
void
sp_table_init (void)
{
	hash_init (&pages, sp_hash_func, sp_less_func, NULL);
	lock_init (&sp_lock);
	next_page = palloc_get_page (PAL_ZERO);
}

unsigned
sp_hash_func (const struct hash_elem *e, void *aux UNUSED)
{
	struct page *p = hash_entry (e, struct page, helem);
	return (unsigned) pg_round_down (p->page_ptr);
}


bool
sp_less_func (const struct hash_elem *a, const struct hash_elem *b, void *aux UNUSED)
{
	struct page *page_a = hash_entry (a, struct page, helem);
	struct page *page_b = hash_entry (b, struct page, helem);

	return page_a->page_ptr < page_b->page_ptr;
}

void *
sp_alloc_new_page (void)
{
	struct page *p;
	uintptr_t page_boundary = (uintptr_t) pg_round_up(next_page);
	if (page_boundary - (uintptr_t) next_page < sizeof(struct page))
	{
		next_page = palloc_get_page(PAL_ZERO);
	}
	p = next_page;
	next_page++;

	hash_insert (&pages, &p->helem);
	return p->page_ptr;
}

void
sp_get_faulting_page (void * fault_addr)
{
	struct page p;
	struct hash_elem *e;
	p.page_ptr = fault_addr;

	e = hash_find (&pages, &p.helem);

	ASSERT (e != NULL);

}
