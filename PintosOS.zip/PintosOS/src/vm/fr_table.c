#include <hash.h>
#include "fr_table.h"
#include "threads/vaddr.h"
#include <debug.h>
#include "threads/palloc.h"
#include "threads/synch.h"
#include <bitmap.h>

static struct bitmap *frame_map;
void *fr_table_lookup_free (void);

void
fr_table_init(void)
{
	size_t num_pages = 0;
	while (palloc_get_page(PAL_USER) != NULL)
	{
		num_pages++;
	}
	
	frame_map = bitmap_create(num_pages);
	/*
	sizeof(struct frame) = 8
	num_pages = 
	*/
	frame_table = palloc_get_page(PAL_ZERO);
}

void *
fr_palloc (void)
{
	//f->page_ptr = palloc_get_page (flags, 1);
	return fr_table_lookup_free();
}

void *
fr_table_lookup_free (void)
{
	size_t idx = bitmap_scan_and_flip (frame_map, 0, 1, 0);
	if(idx == BITMAP_ERROR)
	{
		//swap
		return NULL;
	}
	return (idx * PGSIZE);
}
