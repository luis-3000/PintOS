#include <hash.h>
#include "devices/block.h"

struct page
{
	uint32_t * page_ptr;
	bool swapped;
	block_sector_t disk_location;
	struct hash_elem helem;
};

void sp_table_init (void);

void sp_get_faulting_page(void * fault_addr);
void *sp_alloc_new_page (void);
