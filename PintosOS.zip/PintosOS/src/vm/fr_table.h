#include <hash.h>
#include "threads/palloc.h"

// uint32_t *frames; //An array to create the frames
// 					 //must be initialized with init_ram_pages()

struct frame *frame_table; // Array for the frames

struct frame
{
	void * addr;	
	struct page * page_ptr;
};

void *fr_palloc (void);
void fr_table_init(void);
