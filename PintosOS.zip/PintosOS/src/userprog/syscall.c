#include "userprog/syscall.h"
#include "userprog/process.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "pagedir.h"
#include "threads/vaddr.h"
#include "lib/inttypes.h"

#define SYSCALL_MAX_ARGS 5

static void syscall_handler (struct intr_frame *);

/* Lock for accesssing file system code */
struct lock filesys_lock;

/* OUR NEW SYSTEM CALLS PROTOTYPES */
void syscall_handler (struct intr_frame *f);
void halt (void);
void exit (int status);
int exec (const char *cmd_line);
int wait (pid_t pid);
bool create (const char *file, unsigned initial_size);
bool remove (const char *file);
int open (const char *file);
int filesize (int fd);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);
void seek (int fd, unsigned position);
unsigned tell (int fd);
void close (int fd);

#define is_invalid_address(addr) ((void *) addr >= PHYS_BASE || (void *) addr < (void*)0x08048000)
int is_invalid_address_2 (const uint32_t *addr);

void
syscall_init (void)
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  lock_init(&filesys_lock);
}

static void
check_syscall_stackptr (const uint32_t *esp)
{
    if (is_invalid_address_2(esp))
    {
        exit(-1);
    }
}

static void
check_syscall_args_location (const uint32_t *esp, int num_args)
{
    int i;

    for (i = 0; i < num_args; i++)
    {
        /* check the address of the argument */
        if (is_invalid_address(esp+i))
        {
            exit(-1);
        }
    }
}

int is_invalid_address_2 (const uint32_t *addr)
{
    if (is_invalid_address(addr))
        return 1;

    uint32_t *phys_esp = pagedir_get_page(thread_current()->pagedir, addr);
    return (phys_esp == NULL);
}

static void
check_syscall_args (const uint32_t *esp, int syscall_number)
{
    int invalid = 0;

    /* check that the pointers are to user addresses */
    switch (syscall_number)
    {
        case SYS_EXEC:
        case SYS_CREATE:
        case SYS_REMOVE:
        case SYS_OPEN:
            invalid = is_invalid_address_2((uint32_t*)esp[0]);
            break;
        case SYS_READ:
        case SYS_WRITE:
            invalid = is_invalid_address_2((uint32_t*)esp[1]);
            invalid = invalid || is_invalid_address_2((uint32_t) esp[1] + esp[2]);

            break;
    }
    if (invalid)
        exit(-1);
}

static void
extract_args (int argc, uint32_t argv[SYSCALL_MAX_ARGS], uint32_t *esp)
{
  int i;
  for (i = 0; i < argc; ++i)
  {
      argv[i] = *(esp + i);
  }
}

/* It will need to retrieve the system call number,
   then any system call arguments, and carry out appropriate actions.
*/
static void
syscall_handler (struct intr_frame *f)
{
  int num_args[16] = {0, 1, 1, 1, 2, 1, 1, 1, 3, 3, 2, 1, 1};
  int return_val = -1;
  uint32_t esp[SYSCALL_MAX_ARGS];
  uint32_t syscall_number;

  check_syscall_stackptr(f->esp);/* if esp isn't valid then this won't return */

  syscall_number = *(uint32_t*)f->esp;
  if (syscall_number > SYS_MAX_NR)
      exit(-1);
  check_syscall_args_location(((uint32_t *) f->esp)+1, num_args[syscall_number]);
  extract_args(num_args[syscall_number], esp, (uint32_t*)f->esp+1);

  check_syscall_args(esp, syscall_number);
  switch (syscall_number)
  {
      case SYS_HALT:
          halt();
          break;
      case SYS_EXIT:
          exit ((int)esp[0]);
          break;
      case SYS_EXEC:
          return_val = exec((char*)esp[0]);
          break;
      case SYS_WAIT:
          return_val = wait((pid_t)esp[0]);
          break;
      case SYS_CREATE:
          return_val = create ((char*) esp[0], esp[1]);
          break;
      case SYS_REMOVE:
          return_val = remove ((char *) esp[0]);
          break;
      case SYS_OPEN:
          return_val = open((const char *) esp[0]);
          break;
      case SYS_FILESIZE:
          return_val = filesize(esp[0]);
          break;
      case SYS_READ:
          return_val = read (esp[0], (char *) esp[1], esp[2]);
          break;
      case SYS_WRITE:
          return_val = write (esp[0], (char *) esp[1], esp[2]);
          break;
      case SYS_SEEK:
          seek (esp[0], esp[1]);
          return_val = 1;
          break;
      case SYS_TELL:
          return_val = tell (esp[0]);
          break;
      case SYS_CLOSE:
          close (esp[0]);
          return_val = 1;
          break;
      default:
          exit(-1);
  }

  /* We make sure to return the value back to where it is expected */
  f->eax = return_val;
}


/* Our implementation */
void halt (void)
{
    shutdown_power_off();
}

/* Terminates the current user program, returning status to the kernel.
   If the process's parent waits for it (see below), this is the status
   that will be returned. Conventionally, a status of 0 indicates success
   and nonzero values indicate errors. */
void exit (int status) {
  struct thread *curr_thread = thread_current();
  curr_thread->exit_status = status;
  
  printf("%s: exit(%d)\n", curr_thread->name, status);
  thread_exit();
}

/* Runs the executable whose name is given in cmd_line, passing any
   given arguments, and returns the new process's program id (pid).
   Must return pid -1, which otherwise should not be a valid pid, if
   the program cannot load or run for any reason. Thus, the parent
   process cannot return from the exec until it knows whether the
   child process successfully loaded its executable. You must use
   appropriate synchronization to ensure this. */
pid_t exec (const char *cmd_line){
    struct thread *child_thread;
    tid_t child_tid = process_execute (cmd_line);

    /* The child has left thread_exit, so it's on the all_list and we can find
     * it.
     */
    if (child_tid != TID_ERROR)
    {
        child_thread = find_thread_by_tid (child_tid);
        sema_down (&child_thread->load_success_sema);

        if (thread_current()->load_failed == 1)
        {
            return -1;
        }
    }
    else
    {
        return -1;
    }

    return tid_to_pid(child_tid);
}

/* Waits for a child process pid and retrieves the child's exit status.
   If pid is still alive, waits until it terminates. Then, returns the
   status that pid passed to exit. If pid did not call exit(), but was
   terminated by the kernel (e.g. killed due to an exception), wait(pid)
   must return -1. It is perfectly legal for a parent process to wait for
   child processes that have already terminated by the time the parent
   calls wait, but the kernel must still allow the parent to retrieve its
   child's exit status, or learn that the child was terminated by the
   kernel.

   wait must fail and return -1 immediately if any of the following
   conditions are true:

   * pid does not refer to a direct child of the calling process. pid is
     a direct child of the calling process if and only if the calling
     process received pid as a return value from a successful call to
     exec.

     [Note that children are not inherited: if A spawns child B and B
     spawns child process C, then A cannot wait for C, even if B is dead.
     A call to wait(C) by process A must fail. Similarly, orphaned
     processes are not assigned to a new parent if their parent process
     exits before they do.]

   * The process that calls wait has already called wait on pid. That is,
     a process may wait for any given child at most once.

    Processes may spawn any number of children, wait for them in any
    order, and may even exit without having waited for some or all of
    their children. Your design should consider all the ways in which
    waits can occur. All of a process's resources, including its struct
    thread, must be freed whether its parent ever waits for it or not,
    and regardless of whether the child exits before or after its parent.

    You must ensure that Pintos does not terminate until the initial
    process exits. The supplied Pintos code tries to do this by calling
    process_wait() (in userprog/process.c) from main() (in threads/init.c).
    We suggest that you implement process_wait() according to the
    comment at the top of the function and then implement the wait
    system call in terms of process_wait().

    Implementing this system call requires considerably more work than
    any of the rest. */
int wait (pid_t pid) {

  return process_wait(pid_to_tid(pid));
}


/* Creates a new file called 'file' initially initial_size bytes in size.
   Returns true if successful, false otherwise. Creating a new file does
   not open it: opening the new file is a separate operation which would
   require a 'open' system call. */
bool create (const char *file, unsigned initial_size){

  bool successfully_created;

  if (file == NULL)
      return false;

  lock_acquire (&filesys_lock);
    successfully_created = filesys_create (file, initial_size);
  lock_release (&filesys_lock);

  return successfully_created;
}

/* Deletes the file called file. Returns true if successful, false
   otherwise. A file may be removed regardless of whether it is open or
   closed, and removing an open file does not close it. See Removing an
   Open File, for details.*/
bool remove (const char *file) {

  bool successfully_removed;

  if(file == NULL)
    return false;

  lock_acquire (&filesys_lock);
    successfully_removed = filesys_remove (file);
  lock_release (&filesys_lock);

  return successfully_removed;
}


/*Opens the file called file. Returns a nonnegative integer handle
   called a "file descriptor" (fd), or -1 if the file could not be
   opened.

   File descriptors numbered 0 and 1 are reserved for the console: fd 0
   (STDIN_FILENO) is standard input, fd 1 (STDOUT_FILENO) is standard
   output. The open system call will never return either of these file
   descriptors, which are valid as system call arguments only as
   explicitly described below.

   Each process has an independent set of file descriptors. File
   descriptors are not inherited by child processes.

   When a single file is opened more than once, whether by a single
   process or different processes, each open returns a new file
   descriptor. Different file descriptors for a single file are closed
   independently in separate calls to close and they do not share a file
   position.*/
int open (const char *file) {
    lock_acquire(&filesys_lock);
    struct file *f = filesys_open(file);
    int ret = -1;

    if (f != NULL) {
        struct thread *t = thread_current();
        int fd;
        struct list_elem *elem;

        t->max_fd += 1;
        fd = t->max_fd;
        file_set_fd(f, fd);
        elem = file_get_fd_elem(f);
        list_push_back(&t->fd_list, elem);

        ret = fd;
    }

    lock_release(&filesys_lock);
    return ret;

}

/* Returns the size, in bytes, of the file open as fd. */
int filesize (int fd){
  int size = -1;
  struct file *f;
  struct thread *t;

  if(fd < 2)
    return -1;

  lock_acquire (&filesys_lock);
    t = thread_current();
    f = thread_get_open_file(t, fd);
    size = file_length (f);
  lock_release (&filesys_lock);

  return size;
}


/* Reads size bytes from the file open as fd into buffer. Returns the
   number of bytes actually read (0 at end of file), or -1 if the file
   could not be read (due to a condition other than end of file). Fd 0
   reads from the keyboard using input_getc().*/
int read (int fd, void *buffer, unsigned length){
    lock_acquire (&filesys_lock);
    int res = -1;
    struct thread *t;
    struct file *f;
    if (fd == 0)
    {
        unsigned i;
        char *charbuf = buffer;
        for (i = 0; i < length; i++)
            charbuf[i] = input_getc();
        res = length;
    }
    else if (fd > 1)
    {
        t = thread_current();
        f = thread_get_open_file(t, fd);
        if (f != NULL)
        {
            res = file_read(f, buffer, length);
        }
    }
    lock_release (&filesys_lock);
    return res;
}


/* Writes size bytes from buffer to the open file fd. Returns the number
   of bytes actually written, which may be less than size if some bytes
   could not be written.

   Writing past end-of-file would normally extend the file, but file
   growth is not implemented by the basic file system. The expected
   behavior is to write as many bytes as possible up to end-of-file and
   return the actual number written, or 0 if no bytes could be written at
   all.

   Fd 1 writes to the console. Your code to write to the console should
   write all of buffer in one call to putbuf(), at least as long as size
   is not bigger than a few hundred bytes. (It is reasonable to break up
   larger buffers.) Otherwise, lines of text output by different processes
   may end up interleaved on the console, confusing both human readers and
   our grading scripts.*/

int write (int fd, const void *buffer, unsigned length)
{
    lock_acquire (&filesys_lock);
    int res = -1;
    struct thread *t;
    struct file *f;
    if (fd == 1)
    {
        putbuf((char*)buffer,length);
        res = length;
    }
    else if (fd > 1)
    {
        t = thread_current();

        f = thread_get_open_file (t, fd);

        if (f != NULL)
        {
            res = file_write(f, buffer, length);            
        }
    }
    lock_release (&filesys_lock);
    return res;
}


/* Changes the next byte to be read or written in open file fd to
   position, expressed in bytes from the beginning of the file. (Thus, a
   position of 0 is the file's start.)

   A seek past the current end of a file is not an error. A later read
   obtains 0 bytes, indicating end of file. A later write extends the
   file, filling any unwritten gap with zeros. (However, in Pintos,
   files will have a fixed length until project 4 is complete, so writes
   past end of file will return an error.) These semantics are implemented
   in the file system and do not require any special effort in system call
   implementation.*/
void seek (int fd, unsigned position){
    lock_acquire (&filesys_lock);
    struct thread *t;
    struct file *f;

    if (fd > 1)
    {
        t = thread_current();
        f = thread_get_open_file(t, fd);
        if (f != NULL)
        {
            file_seek(f, position);
        }
    }
    lock_release (&filesys_lock);
}

/* Returns the position of the next byte to be read or written in open
   file fd, expressed in bytes from the beginning of the file.*/
unsigned tell (int fd){
    lock_acquire (&filesys_lock);
    int res = -1;
    struct thread *t;
    struct file *f;

    if (fd > 1)
    {
        t = thread_current();
        f = thread_get_open_file(t, fd);
        if (f != NULL)
        {
            res = file_tell(f);
        }
    }
    lock_release (&filesys_lock);
    return res;
}

/* Closes file descriptor fd. Exiting or terminating a process implicitly
   closes all its open file descriptors, as if by calling this function
   for each one.*/
void close (int fd){
    lock_acquire (&filesys_lock);
    struct thread *t;
    struct file *f;

    if (fd > 1)
    {
        t = thread_current();
        f = thread_get_open_file(t, fd);
        if (f != NULL)
        {
            list_remove(file_get_fd_elem(f));
            file_close(f);
        }
    }
    lock_release (&filesys_lock);
}
